# RSH v14.0 Reproducibility Package

Archival master of the **Resonant Substrate Hypothesis (RSH) v14.0**.  
Includes all documentation, code, figures, and metadata required for reproducibility of the results presented in:

**Gewirtz, J. (2025). _The Resonant Substrate Hypothesis (RSH) v14: A Unifying Law of Information, Energy, and Time — Linking Einstein, Planck, and Shannon through the Gewirtz Invariant._ Zenodo.**  
DOI: [https://doi.org/10.5281/zenodo.17558566](https://doi.org/10.5281/zenodo.17558566)

---

## Author
**Jeffrey Gewirtz**  
Independent Researcher in Theoretical & Mathematical Physics  
ORCID: [0009-0004-8500-0049](https://orcid.org/0009-0004-8500-0049)  
Email: gewirtzjeffrey@gmail.com  

---

## License

- **Text and Figures:** [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/)  
- **Code:** [MIT License](https://opensource.org/licenses/MIT)  
© 2025 Jeffrey Gewirtz. All Rights Reserved (except where otherwise noted).

---

## Package Contents

```
RSH_v14_Reproducibility_Package/
├── README.md
├── /code/
│   ├── run_all.py
│   ├── lindblad_solver.py
│   ├── covariance_dynamics.py
│   └── utils/
├── /data/
│   ├── qubit_T1T2_data.csv
│   ├── schumann_resonances.csv
│   └── gw150914_params.csv
├── /figures/
│   ├── Figure_1.png
│   ├── mi_vs_coupling.png
│   ├── mi_vs_frequency.png
│   └── ...
├── /metadata/
│   ├── RESULTS.json
│   ├── MANIFEST.md
│   └── SHA256_hashes.txt
└── /licenses/
    ├── CC_BY_4.0.txt
    └── MIT.txt
```

---

## Software Requirements

- Python ≥ 3.11  
- NumPy ≥ 1.24  
- SciPy ≥ 1.10  
- Matplotlib ≥ 3.7  
- (Optional) QuTiP ≥ 4.7 — for open-system simulations  

---

## Reproduction Instructions

1. Install dependencies listed above.  
2. Navigate to the `/code/` directory.  
3. Run:

   ```bash
   python run_all.py
   ```

4. Output figures and numerical summaries will appear under `/figures/output/`.  
5. Compare these with the published figures and tables in the RSH v14 paper.

---

## Citation

If you use or adapt this work, please cite:

> **Gewirtz, J. (2025).** *The Resonant Substrate Hypothesis (RSH) v14: A Unifying Law of Information, Energy, and Time — Linking Einstein, Planck, and Shannon through the Gewirtz Invariant.* Zenodo.  
> DOI: [10.5281/zenodo.17558566](https://doi.org/10.5281/zenodo.17558566)

---

**Version:** v14.0  
**Last Updated:** November 2025
